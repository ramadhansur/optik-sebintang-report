
/*
 Template Name: Zegva - Responsive Bootstrap 4 Admin Dashboard
 Author: Themesdesign
 Website: www.themesdesign.in
 File:  Peity init js
 */


$('.peity-line').each(function() {
    $(this).peity("line", $(this).data());
});