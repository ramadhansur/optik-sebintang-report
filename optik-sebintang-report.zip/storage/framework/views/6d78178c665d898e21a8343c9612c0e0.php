<?php $__env->startSection('title'); ?>
Pelanggan BPJS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content">

    <div class="container-fluid">
        <div class="page-title-box">

            <div class="row align-items-center ">
                <div class="col-md-8">
                    <div class="page-title-box">
                        <h4 class="page-title">Pelanggan BPJS</h4>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active">Halaman Data Pelanggan BPJS</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- end page-title -->

        <!-- start top-Contant -->
        <div class="row">
            <div class="col-sm-6 col-xl-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center p-1">
                            <div class="col-lg-11">
                                <h5 class="font-16">Pelanggan Umum</h5>
                                <h4 class="text-primary pt-1 mb-0"><?php echo e($jumlahUmum); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-xl-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center p-1">
                            <div class="col-lg-11">
                                <h5 class="font-16">Pelanggan BPJS</h5>
                                <h4 class="text-success pt-1 mb-0"><?php echo e($jumlahBpjs); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end top-Contant -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">Data Pelanggan BPJS</h4>
                        <p class="sub-title"></p>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="mt-0 header-title">Data Pelanggan Umum</h4>
                                        <p class="sub-title"></p>

                                        <div class="row">
                                            <div class="col-sm-11">
                                                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                    <thead>
                                                        <tr>
                                                            <th>No</th>
                                                            <th>Nama</th>
                                                            <th>Tanggal</th>
                                                            <th>Jenis</th>
                                                            <th>Alamat</th>
                                                            <th>No. Hp</th>
                                                            <th>Ukuran</th>
                                                            <th>Lensa</th>
                                                            <th>Frame</th>
                                                            <th>Harga</th>
                                                            <th>keterangan</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        <?php
                                                            $no = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pu => $pelumum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $harga = $pelumum->harga;
                                                            $harga = number_format($harga, 0, ',', '.');
                                                        ?>
                                                            <tr>
                                                                <td>
                                                                    <b><?php echo e($no++); ?></b>
                                                                </td>
                                                                <?php if(Str::length($pelumum->nama) > 15): ?>
                                                                    <td>
                                                                        <?php echo e(Str::limit($pelumum->nama, 15, "...")); ?>

                                                                    </td>
                                                                <?php else: ?>
                                                                    <td><?php echo e($pelumum->nama); ?></td>
                                                                <?php endif; ?>
                                                                <td><?php echo e(date('d-F-Y', strtotime($pelumum->transaksi_date))); ?></td>
                                                                <td><?php echo e($pelumum->jenis_transaksi); ?></td>
                                                                <td>
                                                                    <?php if($pelumum->alamat == null): ?>
                                                                        -
                                                                    <?php else: ?>
                                                                        <?php echo e($pelumum->alamat); ?>

                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php if($pelumum->no_hp == null): ?>
                                                                        -
                                                                    <?php else: ?>
                                                                        <?php echo e($pelumum->no_hp); ?>

                                                                    <?php endif; ?>
                                                                </td>
                                                                <td><?php echo e($pelumum->ukuran); ?></td>
                                                                <td><?php echo e($pelumum->lensa); ?></td>
                                                                <td><?php echo e($pelumum->frame); ?></td>
                                                                <td>Rp.<?php echo e($harga); ?></td>
                                                                <td>
                                                                    <?php if($pelumum->keterangan == null): ?>
                                                                        -
                                                                    <?php else: ?>
                                                                        <?php echo e($pelumum->keterangan); ?>

                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <a href="#" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalShow<?php echo e($pelumum->id); ?>">Detail</a>
                                                                    <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#modalEdit<?php echo e($pelumum->id); ?>">Ubah</a>
                                                                    <a href="pelangganumum/delete/" class="btn btn-danger btn-sm" id="delete" data-id="<?php echo e($pelumum->id); ?>" data-name="<?php echo e($pelumum->nama); ?>">Hapus</a>
                                                                </td>
                                                            </tr>

                                                            <!-- Modal edit -->
                                                            <div class="modal fade bs-example-modal-center" id="modalEdit<?php echo e($pelumum->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title mt-0">Ubah Data Pelanggan</h5>
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <form action="<?php echo e(url('admin/pelangganbpjs/update', $pelumum->id)); ?>" method="post">
                                                                                <?php echo csrf_field(); ?>
                                                                                <label for="">Nama</label>
                                                                                <input type="text" class="form-control" name="nama" id="nama" value="<?php echo e($pelumum->nama); ?>" required >
                                                                                <label for="">Tanggal Transaksi</label>
                                                                                <input type="date" class="form-control" name="transaksi_date" id="transaksi_date" value="<?php echo e($pelumum->transaksi_date); ?>" required>
                                                                                <label for="">Jenis</label>
                                                                                <input type="text" class="form-control" name="jenis_transaksi" id="jenis" value="<?php echo e($pelumum->jenis_transaksi); ?>" readonly>
                                                                                <label for="">Alamat</label>
                                                                                <textarea class="form-control" name="alamat" id="alamat"><?php echo e($pelumum->alamat); ?></textarea>
                                                                                <label for="">No. Hp</label>
                                                                                <input type="text" class="form-control" name="no_hp" id="no_hp" value="<?php echo e($pelumum->no_hp); ?>">
                                                                                <label for="">Ukuran</label>
                                                                                <input type="text" class="form-control" name="ukuran" id="ukuran" value="<?php echo e($pelumum->ukuran); ?>" required>
                                                                                <label for="">Lensa</label>
                                                                                <input type="text" class="form-control" name="lensa" id="lensa" value="<?php echo e($pelumum->lensa); ?>" required>
                                                                                <label for="">Frame</label>
                                                                                <input type="text" class="form-control" name="frame" id="frame" value="<?php echo e($pelumum->frame); ?>" required>
                                                                                <label for="">Harga</label>
                                                                                <input type="number" class="form-control" name="harga" id="harga" value="<?php echo e($pelumum->harga); ?>" required>
                                                                                <label for="">Keterangan</label>
                                                                                <textarea class="form-control" name="keterangan" id="keterangan"><?php echo e($pelumum->keterangan); ?></textarea>

                                                                                <hr>
                                                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                    <!-- /.modal-content -->
                                                                </div>
                                                                <!-- /.modal-dialog -->
                                                            </div>
                                                            <!-- /.modal -->

                                                            <!-- Modal show -->
                                                            <div class="modal fade bs-example-modal-center" id="modalShow<?php echo e($pelumum->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title mt-0">Detail Pelanggan</h5>
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <label for="">Nama</label>
                                                                            <input type="text" class="form-control" id="nama" value="<?php echo e($pelumum->nama); ?>" readonly>
                                                                            <label for="">Tanggal</label>
                                                                            <input type="text" class="form-control" id="tanggal" value="<?php echo e($pelumum->transaksi_date); ?>" readonly>
                                                                            <label for="">Jenis</label>
                                                                            <input type="text" class="form-control" id="jenis" value="<?php echo e($pelumum->jenis_transaksi); ?>" readonly>
                                                                            <label for="">Alamat</label>
                                                                            <?php if($pelumum->alamat == null): ?>
                                                                                <textarea class="form-control" id="alamat" readonly>-</textarea>
                                                                            <?php else: ?>
                                                                                <textarea class="form-control" id="alamat" readonly><?php echo e($pelumum->alamat); ?></textarea>
                                                                            <?php endif; ?>
                                                                            <label for="">No. Hp</label>
                                                                            <?php if($pelumum->no_hp == null): ?>
                                                                                <input type="text" class="form-control" id="no_hp" value="-" readonly>
                                                                            <?php else: ?>
                                                                                <input type="text" class="form-control" id="no_hp" value="<?php echo e($pelumum->no_hp); ?>" readonly>
                                                                            <?php endif; ?>
                                                                            <label for="">Ukuran</label>
                                                                            <input type="text" class="form-control" id="ukuran" value="<?php echo e($pelumum->ukuran); ?>" readonly>
                                                                            <label for="">Lensa</label>
                                                                            <input type="text" class="form-control" id="lensa" value="<?php echo e($pelumum->lensa); ?>" readonly>
                                                                            <label for="">Frame</label>
                                                                            <input type="text" class="form-control" id="frame" value="<?php echo e($pelumum->frame); ?>" readonly>
                                                                            <label for="">Harga</label>
                                                                            <input type="text" class="form-control" id="harga" value="<?php echo e($pelumum->harga); ?>" readonly>
                                                                            <label for="">Keterangan</label>
                                                                            <?php if($pelumum->keterangan == null): ?>
                                                                                <textarea class="form-control" id="keterangan" readonly>-</textarea>
                                                                            <?php else: ?>
                                                                                <textarea class="form-control" id="keterangan" readonly><?php echo e($pelumum->keterangan); ?></textarea>
                                                                            <?php endif; ?>

                                                                            <hr>
                                                                        </div>
                                                                    </div>
                                                                    <!-- /.modal-content -->
                                                                </div>
                                                                <!-- /.modal-dialog -->
                                                            </div>
                                                            <!-- /.modal -->
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- end col -->
                        </div>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>
    </div>
    <!-- container-fluid -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\optik-sebintang-report\resources\views/pages/pelanggan/bpjs.blade.php ENDPATH**/ ?>