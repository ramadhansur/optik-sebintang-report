<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content">

    <div class="container-fluid">
        <div class="page-title-box">

            <div class="row align-items-center ">
                <div class="col-md-8">
                    <div class="page-title-box">
                        <h4 class="page-title">Dashboard</h4>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active">Welcome to Optik Sebintang Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- end page-title -->

        <!-- start top-Contant -->
        <div class="row">
            <div class="col-sm-6 col-xl-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center p-1">
                            <div class="col-lg-11">
                                <h5 class="font-16">Semua Pelanggan</h5>
                                <h4 class="text-primary pt-1 mb-0"><?php echo e($jumlahPelanggan); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-xl-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center p-1">
                            <div class="col-lg-11">
                                <h5 class="font-16">Pelanggan Bulan ini</h5>
                                <h4 class="text-danger pt-1 mb-0"><?php echo e($bulanIni); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end top-Contant -->

        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Pelanggan Terbaru</h4>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Tanggal</th>
                                        <th scope="col">Jenis</th>
                                        <th scope="col">Alamat</th>
                                        <th scope="col">No. Hp</th>
                                        <th scope="col">Ukuran</th>
                                        <th scope="col">Lensa</th>
                                        <th scope="col">Frame</th>
                                        <th scope="col">Harga</th>
                                        <th scope="col">keterangan</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $pelangganTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pu => $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $harga = $pelanggan->harga;
                                        $harga = number_format($harga, 0, ',', '.');
                                    ?>
                                        <tr>
                                            <td>
                                                <b><?php echo e($no++); ?></b>
                                            </td>
                                            <?php if(Str::length($pelanggan->nama) > 15): ?>
                                                <td>
                                                    <?php echo e(Str::limit($pelanggan->nama, 15, "...")); ?>

                                                </td>
                                            <?php else: ?>
                                                <td><?php echo e($pelanggan->nama); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e(date('d-F-Y', strtotime($pelanggan->transaksi_date))); ?></td>
                                            <td><?php echo e($pelanggan->jenis_transaksi); ?></td>
                                            <td>
                                                <?php if($pelanggan->alamat == null): ?>
                                                    -
                                                <?php else: ?>
                                                    <?php echo e($pelanggan->alamat); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($pelanggan->no_hp == null): ?>
                                                    -
                                                <?php else: ?>
                                                    <?php echo e($pelanggan->no_hp); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($pelanggan->ukuran); ?></td>
                                            <td><?php echo e($pelanggan->lensa); ?></td>
                                            <td><?php echo e($pelanggan->frame); ?></td>
                                            <td>Rp.<?php echo e($harga); ?></td>
                                            <td>
                                                <?php if($pelanggan->keterangan == null): ?>
                                                    -
                                                <?php else: ?>
                                                    <?php echo e($pelanggan->keterangan); ?>

                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- container-fluid -->

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\optik-sebintang-report\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>