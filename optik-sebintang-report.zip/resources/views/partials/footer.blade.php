<footer class="footer">
    © 2023 Optik Sebintang <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Surya</span>.
</footer>
